<?php

$db = @mysqli_connect('127.0.0.1', 'root', 'root', 'test') or die('Ошибка соединения с БД');
mysqli_set_charset($db, "utf8") or die('Не установлена кодировка');

?>