<?php 

require_once 'connect.php';

class Car{

	//для вывода всех позиций в таблице Carinfo
	public function get_all_carinfo(){
		global $db;
		$query = "SELECT * FROM Carinfo";
		$res = mysqli_query($db,$query);
		return mysqli_fetch_all($res,MYSQLI_ASSOC);
	}

	//для вывода всех позиций в таблице Car
	public function get_all_car(){
		global $db;
		$query = "SELECT * FROM Car";
		$res = mysqli_query($db,$query);
		return mysqli_fetch_all($res,MYSQLI_ASSOC);
	}

	//для вывода выбранной позиции в таблице Car
	public function get_car_type($id){
		global $db;
		$query = "SELECT * FROM Car WHERE id = {$id}";
		$res = mysqli_query($db,$query);
		return mysqli_fetch_all($res);
	}

	//для вывода выбранной позиции в таблице Carinfo
	public function get_car_info($id){
		global $db;
		$query = "SELECT * FROM Carinfo WHERE id = {$id}";
		$res = mysqli_query($db,$query);
		return mysqli_fetch_all($res);
	}

	//добавить новую строку в таблицу Carinfo
	public function update_carinfo($carID,$carname){
		global $db;
		$query = "INSERT INTO `carinfo`(`CarID`, `CarName`) VALUES ($carID, '$carname')";
		mysqli_query($db,$query);
	}

	//удалить строку в таблице Carinfo по id
	public function delete_carinfo($id){
		global $db;
		$query = "DELETE FROM `carinfo` WHERE id = $id";
		mysqli_query($db,$query);
	}

	public function print_arr($arr){
    	echo '<pre>' . print_r($arr, true) . '<pre>';
	}
}


$car = new Car();
$messages = $car->get_all_carinfo();
$car->print_arr($messages);

$messages = $car->get_all_car();
$car->print_arr($messages);

$messages = $car->get_car_type(2);
$car->print_arr($messages);

$messages = $car->get_car_info(11);
$car->print_arr($messages);

// $car->update_carinfo(2,'BMW');
// $messages = $car->get_all_carinfo();
// $car->print_arr($messages);

// нужно передать функции id строки,которую хотите удалить
// $car->delete_carinfo();
// $messages = $car->get_all_carinfo();
// $car->print_arr($messages);

















?>